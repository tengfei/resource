library(shiny)
library(ggplot2)

dt <- read.csv("data/count.csv")
colnames(dt)[colnames(dt) == "X"] <- "id"

de <- read.csv("data/de.csv")
colnames(de)[colnames(de) == "X"] <- "id"


shinyServer(function(input, output, session){
    

    

    all_values <- function(DT, x.in, y.in){
        function(x) {
        if (is.null(x))
            return(NULL)
        res <- DT[DT$id == x$id, c("id", x.in, y.in)]
        paste0(names(res), ": ", format(res), collapse = "<br />")
    }}

    reactive({
    
        dt %>% ggvis(prop("x", as.name(input$x)),
                         prop("y", as.name(input$y)),
                         key := ~id) %>%
        layer_points() %>% add_tooltip(all_values(dt, input$x, input$y), "hover")
        })   %>%  
        bind_shiny("scatterplot")
   
    reactive({
        
        de %>% ggvis(prop("x", as.name(input$de.x)),
                     prop("y", as.name(input$de.y)),
                     key := ~id) %>%
            layer_points() %>% 
            add_tooltip(all_values(de, input$de.x, input$de.y), "hover")
    })   %>%  
        bind_shiny("descatterplot")
    
    
    output$table <- renderTable({
        as.data.frame(dt)
    })
    
    output$de.table <- renderTable({
        as.data.frame(de)
    })
})




