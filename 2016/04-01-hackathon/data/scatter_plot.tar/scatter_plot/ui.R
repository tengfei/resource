library(shiny)
library(ggvis)

dt <- read.csv("data/count.csv")
colnames(dt)[colnames(dt) == "X"] <- "id"
dt.input <- subset(dt, select = -id)
de <- read.csv("data/de.csv")
colnames(de)[colnames(de) == "X"] <- "id"
de.input <- subset(de, select = -id)

shinyUI(navbarPage(
    "RNA-seq DE analysis shiny demo",
    tabPanel("Count data", fluidRow(
        column(3, 
               wellPanel(
            selectInput("x", "X Variable:",
                        colnames(dt.input)),
            
            selectInput("y", "Y Variable:",
                        colnames(dt.input))
        )),
        column(9,
               tabsetPanel(type = "tabs", 
                           tabPanel("Plot",
                                    ggvisOutput("scatterplot")),
                           tabPanel("Table", tableOutput("table"))
               ))
    )),
    tabPanel("DE data", fluidRow(
        column(3, 
               wellPanel(
                   selectInput("de.x", "X Variable:",
                               colnames(de.input)),
                   
                   selectInput("de.y", "Y Variable:",
                               colnames(de.input))
               )),
        column(9,
               tabsetPanel(type = "tabs", 
                           tabPanel("Plot",
                                    ggvisOutput("descatterplot")),
                           tabPanel("Table", tableOutput("de.table"))
               ))
    )
             ),
    tabPanel("Report",
             includeHTML("data/rnaseqGene.html"))
   
))



